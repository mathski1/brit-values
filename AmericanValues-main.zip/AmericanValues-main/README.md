# This test is discontinued!

It was fun while it lasted, but this test is no longer receiving updates. bannnedb is now maintaining a copy [here.](https://bannnedb.github.io/American-Values/)

AmericanValues was never meant to be anything more than a project for me to develop other people's code; it was not meant to be an accurate political test. I eventually stopped working on it and forgot it even existed — until Reddit found it, and dozens of users began taking the test. Their results where hilariously inaccurate, prompting a few kind souls to submit issues to suggest improvements, and I definitely appreciate it! Thank yall!

So to give back to those of yall who took the time out of your day to help me make my forgotten project a little less terrrible: I'm releasing Beta 3.0. This will be the last version of AmericanValues I will ever release. Feel free to fork this project and continue my work, but I'll no longer be contributing. I met my goal of adapting 8values, and I'm moving on to other projects.

Being the Internet, it was inevitable that once I was in the spot-light, no matter how small, that rumors would develop: Liberal users began labelling me a ["Trump supporter"](https://www.reddit.com/r/AskALiberal/comments/m4ok7k/what_did_you_get_for_the_american_values_test/gqvkvnv?utm_source=share&utm_medium=web2x&context=3) and an ["actual fascist"](https://www.reddit.com/r/neoliberal/comments/m50rdi/what_did_you_get_for_the_american_values_test/gqxn8wf?utm_source=share&utm_medium=web2x&context=3) — however, both of these assertions are one-hundred percent false. I voted for Rocky De La Fuente (the Reform Party candidate), not Donald Trump. Furthermore, I disavow racism and anti-Semitism of any kind, and the claim that I'm somehow a "Fascist" is quite offensive, considering how I'm transgender and the Nazis would have *literally murdered me.*

I've had arguments with real Fascists, who identify as such and politically align with Hitler, and we're nothing alike; they hate me. I'm a Centrist, not a Nazi. Perhaps from the perspective of a Communist I'd be far-right, but not from the perspective of most Americans. Don't feel bad for mislabelling me, however; the Trump supporters thought I was a Communist for a good while.

\~TheAmeliaMay

# What is AmericanValues?
AmericanValues is a political quiz inspired by 8values, but tailored to the political climate of the United States. You will be presented by a statement, and then you will answer with your opinion on the statement, from Strongly Agree to Strongly Disagree, with each answer slightly affecting your scores. At the end of the quiz, your answers will be compared to the maximum possible for each value, thus giving you a percentage. Answer honestly!

You can take the test [here.](https://theameliamay.github.io/AmericanValues/)
